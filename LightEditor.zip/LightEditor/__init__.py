bl_info = {
    "name": "Light Editor",
    "author": "Robert Rioux aka Blender Bob",
    "location": "3Dview > Light Editor",
    "version": (1, 4, 0),
    "blender": (4, 2, 0),
    "description": "A Light Editor and Light Linking addon",
    "category": "Object",
}

from . import lightEditor
# Import Linking but do not register it by default
from . import Linking

def register():
    lightEditor.register()
    # Do not register Linking here
    # Linking.register()

def unregister():
    # Unregister Linking if it was registered manually
    Linking.unregister()
    lightEditor.unregister()

# Optional: Provide a function to enable Linking later
def enable_linking():
    Linking.register()

# Optional: Provide a function to disable Linking later
def disable_linking():
    Linking.unregister()

if __name__ == "__main__":
    register()