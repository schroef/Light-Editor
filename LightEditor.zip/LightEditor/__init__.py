import bpy
import fnmatch
from bpy.props import (
    BoolProperty,
    IntProperty,
    FloatProperty,
    StringProperty,
    EnumProperty,
)

# Global variables to track active checkboxes
current_active_light = None
current_exclusive_group = None

# Dictionaries to store states
group_checkbox_1_state = {}  # First button on/off per group_key (ON by default)
group_lights_original_state = {}  # Stores original light states for each group
group_checkbox_2_state = {}  # Second button on/off per group_key (OFF by default)
other_groups_original_state = {}  # Stores other groups' states
group_collapse_dict = {}  # Whether each group is collapsed

# Column layout, row scaling
VISIBILITY_COL_SCALE = 1.0
TURN_OFF_OTHERS_COL_SCALE = 1.0
EXPAND_COL_SCALE = 1.0
NAME_COL_SCALE = 1.0
OTHER_COL_SCALE = 0.7
ROW_SCALE = 1.0

def view_layer_items(self, context):
    """Return a list of view layer items for the EnumProperty."""
    items = []
    scene = context.scene
    for view_layer in scene.view_layers:
        # Each tuple is (identifier, name, description)
        items.append((view_layer.name, view_layer.name, ""))
    return items


# Update: Toggle light_enabled => hide_viewport/hide_render
def update_light_enabled(self, context):
    self.hide_viewport = not self.light_enabled
    self.hide_render = not self.light_enabled


def update_light_turn_off_others(self, context):
    global current_active_light

    scene = context.scene

    if self.light_turn_off_others:
        # If there was a previously active light, turn its checkbox off
        if current_active_light and current_active_light != self:
            current_active_light.light_turn_off_others = False

        # Set this light as the current active light
        current_active_light = self

        # Turn off all other lights
        for obj in scene.objects:
            if obj.type == 'LIGHT' and obj.name != self.name:
                if 'prev_light_enabled' not in obj:
                    obj['prev_light_enabled'] = obj.light_enabled
                obj.light_enabled = False
    else:
        # If this checkbox is being turned off
        if current_active_light == self:
            current_active_light = None

        # Restore the previous states of other lights
        for obj in scene.objects:
            if obj.type == 'LIGHT' and obj.name != self.name:
                if 'prev_light_enabled' in obj:
                    obj.light_enabled = obj['prev_light_enabled']
                    del obj['prev_light_enabled']


# Mutually exclusive grouping toggles
def update_group_by_kind(self, context):
    if self.light_editor_kind_alpha:
        self.light_editor_group_by_collection = False


def update_group_by_collection(self, context):
    if self.light_editor_group_by_collection:
        self.light_editor_kind_alpha = False


# Extra Parameters Drawing
def draw_extra_params(box, obj, light):
    # POINT & SPOT
    if light.type in {'POINT', 'SPOT'}:
        row = box.row(align=True)
        row.label(text="Soft Falloff:")
        row.prop(light, "soft_falloff", text="")

        row = box.row(align=True)
        row.label(text="Radius:")
        row.prop(light, "shadow_soft_size", text="")

        row = box.row(align=True)
        row.label(text="Max Bounce:")
        row.prop(light, "max_bounce", text="")

        row = box.row(align=True)
        row.label(text="Cast Shadow:")
        row.prop(light, "use_shadow", text="")

        row = box.row(align=True)
        row.label(text="Multiple Inst:")
        row.prop(light, "multiple_instance", text="")

        row = box.row(align=True)
        row.label(text="Shadow Caustic:")
        row.prop(light, "shadow_caustic", text="")

        # SPOT-SPECIFIC PARAMETERS (only if light.type == 'SPOT')
        if light.type == 'SPOT':
            row = box.row(align=True)
            row.label(text="Spot Size:")
            row.prop(light, "spot_size", text="")

            row = box.row(align=True)
            row.label(text="Blende:")
            row.prop(light, "spot_blend", text="")

            row = box.row(align=True)
            row.label(text="Show Cone:")
            row.prop(light, "show_cone", text="")

    # SUN
    elif light.type == 'SUN':
        row = box.row(align=True)
        row.label(text="Angle:")
        row.prop(light, "angle", text="")

        row = box.row(align=True)
        row.label(text="Max Bounce:")
        row.prop(light, "max_bounce", text="")

        row = box.row(align=True)
        row.label(text="Cast Shadow:")
        row.prop(light, "use_shadow", text="")

        row = box.row(align=True)
        row.label(text="Multiple Inst:")
        row.prop(light, "multiple_instance", text="")

        row = box.row(align=True)
        row.label(text="Shadow Caustic:")
        row.prop(light, "shadow_caustic", text="")

    # AREA
    elif light.type == 'AREA':
        row = box.row(align=True)
        row.label(text="Shape:")
        row.prop(light, "shape", text="")

        row = box.row(align=True)
        row.label(text="Size X:")
        row.prop(light, "size", text="")

        row = box.row(align=True)
        row.label(text="Size Y:")
        row.prop(light, "size_y", text="")

        row = box.row(align=True)
        row.label(text="Max Bounce:")
        row.prop(light, "max_bounce", text="")

        row = box.row(align=True)
        row.label(text="Cast Shadow:")
        row.prop(light, "use_shadow", text="")

        row = box.row(align=True)
        row.label(text="Multi Imp:")
        row.prop(light, "use_multiple_importance", text="")

        row = box.row(align=True)
        row.label(text="Shadow Caustics:")
        row.prop(light, "shadow_caustic", text="")

        row = box.row(align=True)
        row.label(text="Portal:")
        if hasattr(light, "cycles"):
            row.prop(light.cycles, "is_portal", text="")
        else:
            row.label(text="-")

        row = box.row(align=True)
        row.label(text="Spread:")
        row.prop(light, "spread", text="")



# Operator: Toggle Group Collapse
class LIGHT_OT_ToggleGroup(bpy.types.Operator):
    """Collapse or expand a group header."""
    bl_idname = "light_editor.toggle_group"
    bl_label = "Toggle Group"
    group_key: StringProperty()

    def execute(self, context):
        current = group_collapse_dict.get(self.group_key, False)
        group_collapse_dict[self.group_key] = not current
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()
        return {'FINISHED'}


# Operator: Toggle Group All-Off / Original
class LIGHT_OT_ToggleGroupAllOff(bpy.types.Operator):
    """
    First "checkbox" button: ON by default (means "lights in this group are in their original state").
    If pressed OFF => turn them all OFF, storing the previous states.
    Then if turned ON again => restore them from those stored states.
    """
    bl_idname = "light_editor.toggle_group_all_off"
    bl_label = "Toggle Group All Off"
    group_key: StringProperty()

    def execute(self, context):
        global group_checkbox_1_state
        global group_lights_original_state

        is_on = group_checkbox_1_state.get(self.group_key, True)
        group_objs = self._get_group_objects(context, self.group_key)

        if is_on:
            # OFF -> store states, then turn them off
            original_states = {}
            for obj in group_objs:
                original_states[obj.name] = obj.light_enabled
            group_lights_original_state[self.group_key] = original_states
            for obj in group_objs:
                obj.light_enabled = False
            group_checkbox_1_state[self.group_key] = False
        else:
            # ON -> restore
            original_states = group_lights_original_state.get(self.group_key, {})
            for obj in group_objs:
                old_state = original_states.get(obj.name, True)
                obj.light_enabled = old_state
            if self.group_key in group_lights_original_state:
                del group_lights_original_state[self.group_key]
            group_checkbox_1_state[self.group_key] = True

        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()

        return {'FINISHED'}

    def _get_group_objects(self, context, group_key):
        scene = context.scene
        filter_pattern = scene.light_editor_filter.lower()
        if filter_pattern:
            all_lights = [
                obj for obj in scene.objects
                if obj.type == 'LIGHT' and fnmatch.fnmatch(obj.name.lower(), filter_pattern)
            ]
        else:
            all_lights = [obj for obj in scene.objects if obj.type == 'LIGHT']

        if scene.light_editor_group_by_collection and group_key.startswith("coll_"):
            coll_name = group_key[5:]
            return [
                obj for obj in all_lights
                if (
                    obj.users_collection and obj.users_collection[0].name == coll_name
                ) or (not obj.users_collection and coll_name == "No Collection")
            ]

        if scene.light_editor_kind_alpha and group_key.startswith("kind_"):
            kind = group_key[5:]
            return [obj for obj in all_lights if obj.data.type == kind]

        return []


# Operator: Toggle Group Exclusive
class LIGHT_OT_ToggleGroupExclusive(bpy.types.Operator):
    """
    Second "checkbox": by default OFF.
    ON => turn off all other groups (store their states).
    OFF => restore those other groups.
    """
    bl_idname = "light_editor.toggle_group_exclusive"
    bl_label = "Toggle Group Exclusive"
    group_key: StringProperty()

    def execute(self, context):
        global current_exclusive_group
        global group_checkbox_2_state
        global other_groups_original_state

        is_on = group_checkbox_2_state.get(self.group_key, False)

        if not is_on:
            # If there was a previously active exclusive group, turn its checkbox off
            if current_exclusive_group and current_exclusive_group != self.group_key:
                group_checkbox_2_state[current_exclusive_group] = False
                saved_dict = other_groups_original_state.get(current_exclusive_group, {})
                for gk, light_dict in saved_dict.items():
                    grp_objs = self._get_group_objects(context, gk)
                    for obj in grp_objs:
                        old_state = light_dict.get(obj.name, True)
                        obj.light_enabled = old_state
                if current_exclusive_group in other_groups_original_state:
                    del other_groups_original_state[current_exclusive_group]

            # Turn ON => store & off other groups
            others = self._get_all_other_groups(context, self.group_key)
            saved_dict = {}
            for gk in others:
                grp_objs = self._get_group_objects(context, gk)
                saved_dict[gk] = {obj.name: obj.light_enabled for obj in grp_objs}
                for obj in grp_objs:
                    obj.light_enabled = False

            other_groups_original_state[self.group_key] = saved_dict
            group_checkbox_2_state[self.group_key] = True
            current_exclusive_group = self.group_key  # Set this group as the current exclusive group

        else:
            # Turn OFF => restore others
            saved_dict = other_groups_original_state.get(self.group_key, {})
            for gk, light_dict in saved_dict.items():
                grp_objs = self._get_group_objects(context, gk)
                for obj in grp_objs:
                    old_state = light_dict.get(obj.name, True)
                    obj.light_enabled = old_state

            if self.group_key in other_groups_original_state:
                del other_groups_original_state[self.group_key]

            group_checkbox_2_state[self.group_key] = False
            current_exclusive_group = None  # Clear the current exclusive group

        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()

        return {'FINISHED'}

    def _get_all_other_groups(self, context, current_key):
        return [k for k in self._get_all_group_keys(context) if k != current_key]

    def _get_all_group_keys(self, context):
        scene = context.scene
        filter_pattern = scene.light_editor_filter.lower()
        if filter_pattern:
            lights = [
                obj for obj in scene.objects
                if obj.type == 'LIGHT' and fnmatch.fnmatch(obj.name.lower(), filter_pattern)
            ]
        else:
            lights = [obj for obj in scene.objects if obj.type == 'LIGHT']

        group_keys = set()
        if scene.light_editor_group_by_collection:
            for obj in lights:
                if obj.users_collection:
                    coll_name = obj.users_collection[0].name
                else:
                    coll_name = "No Collection"
                group_keys.add(f"coll_{coll_name}")
        elif scene.light_editor_kind_alpha:
            tmap = {'POINT': [], 'SPOT': [], 'SUN': [], 'AREA': []}
            for obj in lights:
                if obj.data.type in tmap:
                    tmap[obj.data.type].append(obj)
            for kind, items in tmap.items():
                if items:
                    group_keys.add(f"kind_{kind}")

        return list(group_keys)

    def _get_group_objects(self, context, group_key):
        scene = context.scene
        filter_pattern = scene.light_editor_filter.lower()
        if filter_pattern:
            all_lights = [
                obj for obj in scene.objects
                if obj.type == 'LIGHT' and fnmatch.fnmatch(obj.name.lower(), filter_pattern)
            ]
        else:
            all_lights = [obj for obj in scene.objects if obj.type == 'LIGHT']

        if scene.light_editor_group_by_collection and group_key.startswith("coll_"):
            coll_name = group_key[5:]
            return [
                obj for obj in all_lights
                if (
                    obj.users_collection and obj.users_collection[0].name == coll_name
                ) or (not obj.users_collection and coll_name == "No Collection")
            ]

        if scene.light_editor_kind_alpha and group_key.startswith("kind_"):
            kind = group_key[5:]
            return [obj for obj in all_lights if obj.data.type == kind]

        return []


# Draw the main row for each light
def draw_main_row(box, obj):
    """
    Draw a single row for an individual light.
    """
    light = obj.data

    # Main row for all controls
    row = box.row(align=True)

    # Sub-row for the three small control buttons
    controls_row = row.row(align=True)
    controls_row.prop(
        obj, "light_enabled", text="",
        icon="CHECKBOX_HLT" if obj.light_enabled else "CHECKBOX_DEHLT"
    )
    controls_row.prop(
        obj, "light_turn_off_others", text="",
        icon="RADIOBUT_ON" if obj.light_turn_off_others else "RADIOBUT_OFF"
    )
    controls_row.prop(
        obj, "light_expanded", text="",
        emboss=True,
        icon='TRIA_DOWN' if obj.light_expanded else 'TRIA_RIGHT'
    )

    # Instead of drawing the Name, Color, and Energy in a single row,
    # create three columns to control the width of each.
    #
    # Column 1: Light Name (default width)
    col_name = row.column(align=True)
    col_name.scale_x = .5  # 0.25 means 25% of normal width (i.e. 75% reduction)
    col_name.prop(obj, "name", text="")  # Editable Light Name

    # Column 2: Light Color (narrowed)
    col_color = row.column(align=True)
    col_color.scale_x = .25  # 0.25 means 25% of normal width (i.e. 75% reduction)
    col_color.prop(light, "color", text="")  # Light Color

    # Column 3: Light Energy (default width)
    col_energy = row.column(align=True)
    col_energy.scale_x = 0.35  # 0.25 means 25% of normal width (i.e. 75% reduction)
    col_energy.prop(light, "energy", text="")  # Light Power


def update_view_layer(self, context):
    """Switch the active View Layer upon user selection."""
    chosen_name = self.light_editor_view_layer
    scene = context.scene
    new_layer = scene.view_layers.get(chosen_name)
    if new_layer:
        context.window.view_layer = new_layer


# Main Panel
class LIGHT_PT_editor(bpy.types.Panel):
    """Panel to view/edit lights with grouping, filtering, and per-group toggles."""
    bl_label = "Light Editor"
    bl_idname = "LIGHT_PT_editor"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Light Editor"

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        # Top controls
        row = layout.row(align=True)
        row.prop(scene, "light_editor_kind_alpha", text="Group by Kind")
        row.prop(scene, "light_editor_group_by_collection", text="Group by Collection")
        layout.prop(scene, "light_editor_filter", text="Filter")

        # If grouping by Collection is ON, show the "Render Layer" dropdown
        if scene.light_editor_group_by_collection:
            layout.prop(scene, "light_editor_view_layer", text="Render Layer")
            layout.separator()

        # Gather lights from filter
        filter_pattern = scene.light_editor_filter.lower()
        if filter_pattern:
            lights = [
                obj for obj in scene.objects
                if obj.type == 'LIGHT' and fnmatch.fnmatch(obj.name.lower(), filter_pattern)
            ]
        else:
            lights = [obj for obj in scene.objects if obj.type == 'LIGHT']

        # GROUP BY COLLECTION
        if scene.light_editor_group_by_collection:
            groups = {}
            for obj in lights:
                if obj.users_collection:
                    group_name = obj.users_collection[0].name
                else:
                    group_name = "No Collection"
                groups.setdefault(group_name, []).append(obj)

            for group_name, group_objs in groups.items():
                group_key = f"coll_{group_name}"
                collapsed = group_collapse_dict.get(group_key, False)
                header_box = layout.box()
                header_row = header_box.row(align=True)

                # First "checkbox" => ON by default
                is_on_1 = group_checkbox_1_state.get(group_key, True)
                icon_1 = 'CHECKBOX_HLT' if is_on_1 else 'CHECKBOX_DEHLT'
                op_1 = header_row.operator(
                    "light_editor.toggle_group_all_off",
                    text="",
                    icon=icon_1,
                    depress=is_on_1
                )
                op_1.group_key = group_key

                # Second "circle icon" => OFF by default
                is_on_2 = group_checkbox_2_state.get(group_key, False)
                icon_2 = 'RADIOBUT_ON' if is_on_2 else 'RADIOBUT_OFF'
                op_2 = header_row.operator(
                    "light_editor.toggle_group_exclusive",
                    text="",
                    icon=icon_2,
                    depress=is_on_2
                )
                op_2.group_key = group_key

                # Collapse/expand triangle
                op_tri = header_row.operator(
                    "light_editor.toggle_group",
                    text="",
                    emboss=True,
                    icon='TRIA_RIGHT' if collapsed else 'TRIA_DOWN'
                )
                op_tri.group_key = group_key

                header_row.label(text=group_name, icon='OUTLINER_COLLECTION')

                if not collapsed:
                    for obj in group_objs:
                        draw_main_row(header_box, obj)
                        if obj.light_expanded:
                            extra_box = header_box.box()
                            extra_box.label(text="Extra Parameters:")
                            draw_extra_params(extra_box, obj, obj.data)

        # GROUP BY KIND
        elif scene.light_editor_kind_alpha:
            groups = {'POINT': [], 'SPOT': [], 'SUN': [], 'AREA': []}
            for obj in lights:
                if obj.data.type in groups:
                    groups[obj.data.type].append(obj)

            for kind in ('POINT', 'SPOT', 'SUN', 'AREA'):
                if groups[kind]:
                    group_key = f"kind_{kind}"
                    collapsed = group_collapse_dict.get(group_key, False)

                    header_box = layout.box()
                    header_row = header_box.row(align=True)

                    # First "checkbox" => ON by default
                    is_on_1 = group_checkbox_1_state.get(group_key, True)
                    icon_1 = 'CHECKBOX_HLT' if is_on_1 else 'CHECKBOX_DEHLT'
                    op_1 = header_row.operator(
                        "light_editor.toggle_group_all_off",
                        text="",
                        icon=icon_1,
                        depress=is_on_1
                    )
                    op_1.group_key = group_key

                    # Second "circle icon" => OFF by default
                    is_on_2 = group_checkbox_2_state.get(group_key, False)
                    icon_2 = 'RADIOBUT_ON' if is_on_2 else 'RADIOBUT_OFF'
                    op_2 = header_row.operator(
                        "light_editor.toggle_group_exclusive",
                        text="",
                        icon=icon_2,
                        depress=is_on_2
                    )
                    op_2.group_key = group_key

                    # Collapse/expand triangle
                    op_tri = header_row.operator(
                        "light_editor.toggle_group",
                        text="",
                        emboss=True,
                        icon='TRIA_RIGHT' if collapsed else 'TRIA_DOWN'
                    )
                    op_tri.group_key = group_key

                    header_row.label(text=f"{kind} Lights", icon='LIGHT_DATA')

                    if not collapsed:
                        for obj in groups[kind]:
                            draw_main_row(header_box, obj)
                            if obj.light_expanded:
                                extra_box = header_box.box()
                                extra_box.label(text="Extra Parameters:")
                                draw_extra_params(extra_box, obj, obj.data)


        # NO GROUPING => ALPHABETICAL
        else:
            sorted_lights = sorted(lights, key=lambda obj: obj.name.lower())
            box = layout.box()
            box.label(text="All Lights (Alphabetical)", icon='LIGHT_DATA')

            for obj in sorted_lights:
                draw_main_row(box, obj)
                if obj.light_expanded:
                    extra_box = box.box()
                    extra_box.label(text="Extra Parameters:")
                    draw_extra_params(extra_box, obj, obj.data)

# Registration
classes = (
    LIGHT_OT_ToggleGroup,
    LIGHT_OT_ToggleGroupAllOff,
    LIGHT_OT_ToggleGroupExclusive,
    LIGHT_PT_editor,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    # Scene properties for filtering/grouping
    bpy.types.Scene.light_editor_filter = StringProperty(
        name="Filter",
        description="Filter lights by name (wildcards supported, case-insensitive)",
        default=""
    )
    bpy.types.Scene.light_editor_kind_alpha = BoolProperty(
        name="Group by Kind",
        description="If True, lights are grouped by kind; if False, sorted alphabetically.",
        default=True,
        update=update_group_by_kind
    )
    bpy.types.Scene.light_editor_group_by_collection = BoolProperty(
        name="Group by Collection",
        description="If True, lights are grouped by collection; if False, sorted alphabetically.",
        default=False,
        update=update_group_by_collection
    )

    # Add the new View Layer enum property with an update function that really switches layers
    bpy.types.Scene.light_editor_view_layer = EnumProperty(
        name="View Layer",
        description="Choose a view layer (aka 'Render Layer')",
        items=view_layer_items,
        update=update_view_layer
    )

    # Light (data) custom properties
    bpy.types.Light.soft_falloff = BoolProperty(
        name="Soft Falloff",
        description="Enable soft falloff",
        default=False
    )
    bpy.types.Light.max_bounce = IntProperty(
        name="Max Bounce",
        description="Maximum bounce for the light",
        default=0,
        min=0,
        max=10
    )
    bpy.types.Light.multiple_instance = BoolProperty(
        name="Multiple Instance",
        description="Enable multiple instance",
        default=False
    )
    bpy.types.Light.shadow_caustic = BoolProperty(
        name="Shadow Caustic",
        description="Enable shadow caustic",
        default=False
    )
    bpy.types.Light.spread = FloatProperty(
        name="Spread",
        description="Light spread for area lights",
        default=0.0,
        min=0.0,
        max=1.0
    )

    # Object properties for light objects.
    bpy.types.Object.light_enabled = BoolProperty(
        name="Enabled",
        description="Toggle light viewport and render visibility",
        default=True,
        update=update_light_enabled
    )
    bpy.types.Object.light_turn_off_others = BoolProperty(
        name="Turn Off Others",
        description="When checked, all other lights will be turned off. Unchecking restores their previous visibility.",
        default=False,
        update=update_light_turn_off_others
    )
    bpy.types.Object.light_expanded = BoolProperty(
        name="Expanded",
        description="Show extra light parameters",
        default=False
    )
    
    bpy.types.Scene.light_editor_view_layer = EnumProperty(
        name="View Layer",
        description="Choose a view layer (aka 'Render Layer')",
        items=view_layer_items,  # Now this function is defined
        update=update_view_layer
    )

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

    del bpy.types.Scene.light_editor_filter
    del bpy.types.Scene.light_editor_kind_alpha
    del bpy.types.Scene.light_editor_group_by_collection
    del bpy.types.Scene.light_editor_view_layer  # remove the new enum
    del bpy.types.Light.soft_falloff
    del bpy.types.Light.max_bounce
    del bpy.types.Light.multiple_instance
    del bpy.types.Light.shadow_caustic
    del bpy.types.Light.spread
    del bpy.types.Object.light_enabled
    del bpy.types.Object.light_turn_off_others
    del bpy.types.Object.light_expanded


if __name__ == "__main__":
    register()