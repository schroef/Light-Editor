# Light-Editor
A Blender addon to manage all the lights in a spreadsheet like UI
